import Header from "@/components/Header";
import ShowcaseSection from "@/components/ShowcaseSection";
import Footer from "@/components/Footer";

const Showcase = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <ShowcaseSection />
      <Footer />
    </div>
  );
};

export default Showcase;
