import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Terms = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold text-gray-800 mb-8">Terms of Service</h1>
            <div className="space-y-6 text-gray-600 leading-relaxed">
              <p className="text-sm text-gray-500">Last updated: {new Date().toLocaleDateString()}</p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">1. Acceptance of Terms</h2>
              <p>
                By accessing and using FerozAI Website & App Builder, you agree to be bound by these Terms of Service and all applicable laws and regulations.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">2. Use License</h2>
              <p>
                We grant you a personal, non-transferable, non-exclusive license to use our platform for your business or personal projects, subject to these terms.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">3. User Responsibilities</h2>
              <p>
                You are responsible for maintaining the confidentiality of your account and for all activities that occur under your account. You agree to use the service only for lawful purposes.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">4. Intellectual Property</h2>
              <p>
                The content you create using our platform belongs to you. However, our platform, including all software, designs, and documentation, remains our intellectual property.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">5. Payment Terms</h2>
              <p>
                Subscription fees are billed in advance on a recurring basis. All fees are non-refundable except as required by law.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">6. Termination</h2>
              <p>
                We may terminate or suspend your account at any time for violation of these terms. You may cancel your subscription at any time.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">7. Limitation of Liability</h2>
              <p>
                FerozAI shall not be liable for any indirect, incidental, special, or consequential damages arising out of your use of the service.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">8. Changes to Terms</h2>
              <p>
                We reserve the right to modify these terms at any time. We will notify users of any material changes via email or through the platform.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Terms;
