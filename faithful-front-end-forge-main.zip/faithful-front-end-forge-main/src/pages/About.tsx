import Header from "@/components/Header";
import Footer from "@/components/Footer";

const About = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold text-gray-800 mb-8">About FerozAI</h1>
            <div className="space-y-6 text-gray-600 leading-relaxed">
              <p className="text-lg">
                Welcome to FerozAI Website & App Builder - your ultimate solution for creating stunning websites and mobile applications without writing a single line of code.
              </p>
              <p>
                Our AI-powered platform revolutionizes the way you build digital experiences. Whether you're an entrepreneur, small business owner, or creative professional, FerozAI empowers you to bring your vision to life with ease and speed.
              </p>
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">Our Mission</h2>
              <p>
                We believe that everyone should have the power to create beautiful, functional websites and apps. Our mission is to democratize digital creation by making it accessible, affordable, and incredibly easy.
              </p>
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">Why Choose FerozAI?</h2>
              <ul className="list-disc list-inside space-y-2">
                <li>AI-powered design assistance</li>
                <li>No coding skills required</li>
                <li>Lightning-fast deployment</li>
                <li>Mobile-responsive designs</li>
                <li>24/7 customer support</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default About;
