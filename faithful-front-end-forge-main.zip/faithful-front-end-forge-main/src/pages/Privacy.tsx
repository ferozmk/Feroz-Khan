import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Privacy = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold text-gray-800 mb-8">Privacy Policy</h1>
            <div className="space-y-6 text-gray-600 leading-relaxed">
              <p className="text-sm text-gray-500">Last updated: {new Date().toLocaleDateString()}</p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">1. Information We Collect</h2>
              <p>
                We collect information that you provide directly to us, including when you create an account, use our services, or communicate with us. This may include your name, email address, and usage data.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">2. How We Use Your Information</h2>
              <p>
                We use the information we collect to provide, maintain, and improve our services, to communicate with you, and to protect our users and services.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">3. Information Sharing</h2>
              <p>
                We do not share your personal information with third parties except as described in this policy. We may share information with service providers who assist us in operating our platform.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">4. Data Security</h2>
              <p>
                We implement appropriate security measures to protect your personal information from unauthorized access, alteration, or destruction.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">5. Your Rights</h2>
              <p>
                You have the right to access, update, or delete your personal information at any time. Contact us if you wish to exercise these rights.
              </p>
              
              <h2 className="text-2xl font-semibold text-gray-800 mt-8 mb-4">6. Contact Us</h2>
              <p>
                If you have questions about this Privacy Policy, please contact us through our contact page.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Privacy;
