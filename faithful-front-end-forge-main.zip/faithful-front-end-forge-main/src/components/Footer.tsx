import { Sparkles } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-white border-t border-gray-200 py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2 mb-6 md:mb-0">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-semibold text-gray-800">
              FerozAI Website & App Builder
            </span>
          </a>
          
          {/* Navigation Links */}
          <nav className="flex items-center gap-8">
            <a href="/about" className="text-gray-600 hover:text-gray-900 transition-colors">
              About
            </a>
            <a href="/contact" className="text-gray-600 hover:text-gray-900 transition-colors">
              Contact
            </a>
            <a href="/privacy" className="text-gray-600 hover:text-gray-900 transition-colors">
              Privacy
            </a>
            <a href="/terms" className="text-gray-600 hover:text-gray-900 transition-colors">
              Terms
            </a>
          </nav>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-200 text-center text-gray-500 text-sm">
          © 2024 FerozAI Website & App Builder. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;