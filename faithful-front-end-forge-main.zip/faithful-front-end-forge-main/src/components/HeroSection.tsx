import { Button } from "@/components/ui/button";
import { Monitor, Smartphone } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="min-h-screen bg-gradient-hero text-white relative overflow-hidden">
      {/* Enhanced decorative circles with multiple glow layers */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-20 -right-20 w-96 h-96 rounded-full border border-white/30 blur-3xl bg-gradient-to-br from-white/10 to-purple-300/20 animate-pulse"></div>
        <div className="absolute top-1/2 -left-32 w-64 h-64 rounded-full border border-white/30 blur-2xl bg-gradient-to-tr from-blue-300/20 to-white/10 animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-20 right-1/4 w-32 h-32 rounded-full border border-white/30 bg-white/10 blur-xl animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/4 left-1/4 w-4 h-4 rounded-full bg-white/40 shadow-[0_0_20px_rgba(255,255,255,0.8)] animate-pulse"></div>
        <div className="absolute bottom-1/3 left-20 w-6 h-6 rounded-full bg-white/30 shadow-[0_0_25px_rgba(255,255,255,0.7)] animate-pulse" style={{ animationDelay: '0.5s' }}></div>
        <div className="absolute top-20 right-1/3 w-8 h-8 rounded-full bg-white/20 shadow-[0_0_30px_rgba(255,255,255,0.6)] animate-pulse" style={{ animationDelay: '1.5s' }}></div>
      </div>
      
      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              BUILD YOUR DIGITAL<br />
              MASTERPIECE. SMARTER & FASTER.
            </h1>
            
            <p className="text-lg md:text-xl text-white/90 max-w-lg">
              Revolutionize your online presence with AI powered 
              and mobile app creation, no code needed.
            </p>
            
            <a href="/signup">
              <Button 
                className="bg-white/20 hover:bg-white/30 text-white border border-white/30 px-8 py-3 text-lg backdrop-blur-sm hover:scale-105 transition-transform shadow-xl shadow-white/20"
                size="lg"
              >
                Start Your Free Trial
              </Button>
            </a>
          </div>
          
          <div className="relative" style={{ perspective: '1500px' }}>
            <div className="flex items-center justify-center gap-6">
              {/* Laptop mockup with enhanced 3D effect */}
              <div className="relative group animate-fade-in" style={{ animationDelay: '0.2s', transformStyle: 'preserve-3d' }}>
                {/* Multiple glow layers for depth */}
                <div className="absolute inset-0 bg-gradient-to-br from-purple-500/40 to-blue-500/40 rounded-2xl blur-2xl transform group-hover:scale-110 transition-all duration-500"></div>
                <div className="absolute inset-0 bg-gradient-to-br from-purple-400/30 to-blue-400/30 rounded-2xl blur-xl transform group-hover:scale-105 transition-all duration-500"></div>
                
                <div className="relative bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 rounded-2xl p-2 transform rotate-2 hover:rotate-0 hover:scale-105 transition-all duration-500 group-hover:translate-y-[-8px]" 
                  style={{ 
                    boxShadow: '0 30px 60px -15px rgba(0, 0, 0, 0.7), 0 0 60px rgba(168, 85, 247, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
                    transform: 'rotateY(2deg) rotateX(-2deg)'
                  }}>
                  {/* Screen bezel with metallic effect */}
                  <div className="bg-gradient-to-br from-gray-800 via-gray-700 to-gray-800 rounded-xl p-1">
                    <div className="bg-gradient-to-br from-white via-gray-50 to-gray-100 rounded-lg w-72 h-44 p-4 relative overflow-hidden shadow-inner">
                      {/* Glossy screen overlay */}
                      <div className="absolute inset-0 bg-gradient-to-br from-white/40 via-transparent to-transparent opacity-50"></div>
                      
                      {/* Window controls with shine */}
                      <div className="flex items-center gap-2 mb-3 relative z-10">
                        <div className="w-3 h-3 rounded-full bg-gradient-to-br from-red-400 to-red-600 shadow-[0_2px_8px_rgba(239,68,68,0.6)]"></div>
                        <div className="w-3 h-3 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 shadow-[0_2px_8px_rgba(234,179,8,0.6)]"></div>
                        <div className="w-3 h-3 rounded-full bg-gradient-to-br from-green-400 to-green-600 shadow-[0_2px_8px_rgba(34,197,94,0.6)]"></div>
                      </div>
                      
                      {/* Content with enhanced gradients */}
                      <div className="space-y-2 relative z-10">
                        <div className="h-24 bg-gradient-to-br from-purple-400 via-purple-500 to-blue-600 rounded-lg shadow-[0_4px_20px_rgba(168,85,247,0.4)] relative overflow-hidden">
                          <div className="absolute inset-0 bg-gradient-to-tr from-white/30 via-white/10 to-transparent"></div>
                          <div className="absolute top-0 left-0 w-full h-full bg-white/10 backdrop-blur-[2px]"></div>
                        </div>
                        <div className="flex gap-2">
                          <div className="h-4 bg-gradient-to-r from-gray-300 to-gray-400 rounded flex-1 shadow-sm"></div>
                          <div className="h-4 bg-gradient-to-r from-gray-300 to-gray-400 rounded w-16 shadow-sm"></div>
                        </div>
                        <div className="h-4 bg-gradient-to-r from-gray-300 to-gray-400 rounded w-24 shadow-sm"></div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Keyboard base with depth */}
                  <div className="h-3 bg-gradient-to-b from-gray-700 via-gray-800 to-gray-900 rounded-b-xl mt-1 shadow-inner relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gray-600 to-transparent"></div>
                  </div>
                </div>
                
                {/* Reflection effect */}
                <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white/5 to-transparent blur-sm transform translate-y-full"></div>
              </div>
              
              {/* Mobile mockup with enhanced 3D effect */}
              <div className="relative group animate-fade-in" style={{ animationDelay: '0.4s', transformStyle: 'preserve-3d' }}>
                {/* Multiple glow layers */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/40 to-purple-500/40 rounded-3xl blur-2xl transform group-hover:scale-110 transition-all duration-500"></div>
                <div className="absolute inset-0 bg-gradient-to-br from-blue-400/30 to-purple-400/30 rounded-3xl blur-xl transform group-hover:scale-105 transition-all duration-500"></div>
                
                <div className="relative bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 rounded-3xl p-2 transform -rotate-3 hover:rotate-0 hover:scale-105 transition-all duration-500 group-hover:translate-y-[-8px]" 
                  style={{ 
                    boxShadow: '0 30px 60px -15px rgba(0, 0, 0, 0.7), 0 0 60px rgba(59, 130, 246, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
                    transform: 'rotateY(-2deg) rotateX(-2deg)'
                  }}>
                  {/* Phone bezel with metallic effect */}
                  <div className="bg-gradient-to-br from-gray-800 via-gray-700 to-gray-800 rounded-2xl p-1">
                    <div className="bg-gradient-to-br from-white via-gray-50 to-gray-100 rounded-2xl w-36 h-64 p-3 relative overflow-hidden shadow-inner">
                      {/* Glossy screen overlay */}
                      <div className="absolute inset-0 bg-gradient-to-br from-white/40 via-transparent to-transparent opacity-50 rounded-2xl"></div>
                      
                      {/* Notch with depth */}
                      <div className="h-5 bg-gradient-to-b from-gray-900 to-black rounded-full w-20 mx-auto mb-2 shadow-[inset_0_2px_4px_rgba(0,0,0,0.5)] relative z-10">
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-8 h-1 bg-gray-800 rounded-full"></div>
                      </div>
                      
                      {/* Screen content */}
                      <div className="space-y-2 relative z-10">
                        <div className="h-20 bg-gradient-to-br from-purple-400 via-purple-500 to-blue-600 rounded-xl shadow-[0_4px_20px_rgba(168,85,247,0.4)] relative overflow-hidden">
                          <div className="absolute inset-0 bg-gradient-to-tr from-white/30 via-white/10 to-transparent"></div>
                          <div className="absolute top-0 left-0 w-full h-full bg-white/10 backdrop-blur-[2px]"></div>
                        </div>
                        <div className="h-2 bg-gradient-to-r from-gray-300 to-gray-400 rounded shadow-sm"></div>
                        <div className="h-2 bg-gradient-to-r from-gray-300 to-gray-400 rounded w-24 shadow-sm"></div>
                        <div className="flex gap-2 mt-4">
                          <div className="h-10 bg-gradient-to-br from-purple-400 via-purple-500 to-purple-600 rounded-lg flex-1 shadow-[0_4px_12px_rgba(168,85,247,0.4)]"></div>
                          <div className="h-10 bg-gradient-to-br from-gray-300 to-gray-400 rounded-lg flex-1 shadow-md"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Reflection effect */}
                <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white/5 to-transparent blur-sm transform translate-y-full"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;