import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

const Header = () => {
  return (
    <header className="w-full bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <a href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <span className="text-lg font-semibold text-gray-800">
            FerozAI Website & App Builder
          </span>
        </a>
        
        <nav className="hidden md:flex items-center gap-8">
          <a href="/features" className="text-gray-600 hover:text-gray-900 transition-colors">
            Features
          </a>
          <a href="/showcase" className="text-gray-600 hover:text-gray-900 transition-colors">
            Showcase
          </a>
          <a href="/pricing" className="text-gray-600 hover:text-gray-900 transition-colors">
            Pricing
          </a>
        </nav>
        
        <a href="/login">
          <Button className="bg-primary hover:bg-primary/90 text-white px-6">
            Login
          </Button>
        </a>
      </div>
    </header>
  );
};

export default Header;