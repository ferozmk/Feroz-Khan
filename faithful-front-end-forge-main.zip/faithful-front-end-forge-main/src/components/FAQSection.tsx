import { ChevronDown } from "lucide-react";
import { useState } from "react";

const FAQSection = () => {
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);

  const faqs = [
    {
      question: "Do I need design skills to use FerozAI website builder?",
      answer: "No, you don't need any design skills. Our AI-powered platform handles all the design work for you."
    },
    {
      question: "Can I create mobile apps with FerozAI?",
      answer: "Yes, FerozAI supports both website and mobile app creation with no coding required."
    },
    {
      question: "What kind of support do you offer?",
      answer: "We offer 24/7 customer support through chat, email, and phone for all our users."
    },
    {
      question: "Is there a free trial available?",
      answer: "Yes, we offer a 14-day free trial with access to all basic features."
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenFAQ(openFAQ === index ? null : index);
  };

  return (
    <section className="py-20 bg-section-bg">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            {/* Left column */}
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-8">
                Frequently Asked Questions
              </h2>
              
              <div className="space-y-4">
                {faqs.slice(0, 2).map((faq, index) => (
                  <div key={index} className="bg-white rounded-lg shadow-sm">
                    <button
                      onClick={() => toggleFAQ(index)}
                      className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
                    >
                      <span className="font-medium text-gray-800">{faq.question}</span>
                      <ChevronDown 
                        className={`w-5 h-5 text-gray-500 transition-transform ${
                          openFAQ === index ? 'rotate-180' : ''
                        }`} 
                      />
                    </button>
                    {openFAQ === index && (
                      <div className="px-6 pb-4">
                        <p className="text-gray-600">{faq.answer}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            {/* Right column */}
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-8">
                Frequently Asked Questions
              </h2>
              
              <div className="space-y-4">
                {faqs.slice(2).map((faq, index) => (
                  <div key={index + 2} className="bg-white rounded-lg shadow-sm">
                    <button
                      onClick={() => toggleFAQ(index + 2)}
                      className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
                    >
                      <span className="font-medium text-gray-800">{faq.question}</span>
                      <ChevronDown 
                        className={`w-5 h-5 text-gray-500 transition-transform ${
                          openFAQ === index + 2 ? 'rotate-180' : ''
                        }`} 
                      />
                    </button>
                    {openFAQ === index + 2 && (
                      <div className="px-6 pb-4">
                        <p className="text-gray-600">{faq.answer}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;