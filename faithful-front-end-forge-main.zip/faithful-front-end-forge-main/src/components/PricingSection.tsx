import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

const PricingSection = () => {
  const plans = [
    {
      name: "Basic",
      price: "$29",
      period: "/month",
      description: "Like people feel it new boost speedbook status transactions",
      features: [
        "Basic website builder",
        "5 pages included",
        "Basic templates"
      ]
    },
    {
      name: "Pro",
      price: "$59",
      period: "/month",
      description: "Like people one it help boost speedbook status transactions",
      features: [
        "Advanced website builder",
        "Unlimited pages",
        "Premium templates",
        "AI-powered design"
      ]
    },
    {
      name: "Enterprise",
      price: "$59",
      period: "/month",
      description: "Companies that keep virtual manifolds would premium",
      features: [
        "Full platform access",
        "Custom development",
        "Priority support",
        "White-label options"
      ]
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Simple, Transparent Pricing
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div key={index} className="bg-white border border-gray-200 rounded-xl p-8 shadow-sm hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold text-gray-800 mb-2">{plan.name}</h3>
              <div className="mb-4">
                <span className="text-3xl font-bold text-gray-800">{plan.price}</span>
                <span className="text-gray-600">{plan.period}</span>
              </div>
              <p className="text-gray-600 text-sm mb-6 leading-relaxed">
                {plan.description}
              </p>
              <a href="/signup">
                <Button className="w-full bg-primary hover:bg-primary/90 text-white mb-6">
                  Choose Plan
                </Button>
              </a>
              <ul className="space-y-3">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center gap-3">
                    <Check className="w-4 h-4 text-green-500" />
                    <span className="text-gray-600 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingSection;