import { Globe, Smartphone, Palette, Zap } from "lucide-react";

const FeaturesSection = () => {
  const features = [
    {
      icon: <Globe className="w-8 h-8 text-primary" />,
      title: "Build Websites",
      subtitle: "Instantly"
    },
    {
      icon: <Smartphone className="w-8 h-8 text-primary" />,
      title: "Build Mobile Apps",
      subtitle: "Easily"
    },
    {
      icon: <Palette className="w-8 h-8 text-primary" />,
      title: "AI-Powered Design",
      subtitle: ""
    },
    {
      icon: <Zap className="w-8 h-8 text-primary" />,
      title: "Fast & Code-Free",
      subtitle: ""
    }
  ];

  return (
    <section className="py-20 bg-section-bg">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Features Designed for Your Success.
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white rounded-xl p-8 text-center shadow-sm hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-1">
                {feature.title}
              </h3>
              {feature.subtitle && (
                <p className="text-gray-600">{feature.subtitle}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;