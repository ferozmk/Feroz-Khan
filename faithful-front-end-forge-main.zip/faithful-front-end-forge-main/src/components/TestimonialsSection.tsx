const TestimonialsSection = () => {
  return (
    <section className="py-20 bg-section-bg">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Trusted by Creators Worldwide
          </h2>
        </div>
        
        <div className="max-w-4xl mx-auto space-y-8">
          {/* First testimonial */}
          <div className="bg-white rounded-xl p-8 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-blue-400 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-lg">A</span>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <div className="flex text-yellow-400">
                    ★★★★★
                  </div>
                </div>
                <p className="text-gray-600 mb-2">
                  "A Google Apps I couldn't Soonsleeps."
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Customer testimonial</span>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-blue-500 rounded"></div>
                    <span className="font-semibold text-gray-800">FutureFlow</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Second testimonial */}
          <div className="bg-white rounded-xl p-8 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-blue-400 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-lg">T</span>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <div className="flex text-yellow-400">
                    ★★★★★
                  </div>
                </div>
                <p className="text-gray-600 mb-2">
                  "Two icons Petrasoft creator tool representative."
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Customer testimonial</span>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-orange-500 rounded"></div>
                    <span className="font-semibold text-gray-800">DesignLab</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Additional section */}
          <div className="text-center mt-16">
            <h3 className="text-2xl font-bold text-gray-800 mb-8">
              FeatureGenelly Consoars
            </h3>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;